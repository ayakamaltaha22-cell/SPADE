import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
from sentence_transformers import SentenceTransformer
from datasets import Dataset
from spade_utils import (
    curate_dataset, 
    generate_instruction_dataset,
    apply_adapters,
    prepare_data_collator
)

BASE_MODEL = "gpt2"
DOMAIN_CORPUS_PATH = "data/biomedical_corpus.json"
ADAPTER_SAVE_DIR = "adapters/bio"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# Load base model
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
model = AutoModelForCausalLM.from_pretrained(BASE_MODEL).to(DEVICE)

# Stage 1: Semantic Filtering
sentence_model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
curated_data = curate_dataset(DOMAIN_CORPUS_PATH, sentence_model, tokenizer)

# Stage 2: IFT
ift_args = TrainingArguments(
    output_dir="./results_ift",
    per_device_train_batch_size=4,
    num_train_epochs=1,
    learning_rate=5e-5,
    fp16=True,
    save_strategy="no",
)

ift_trainer = Trainer(
    model=model,
    args=ift_args,
    train_dataset=curated_data,
    tokenizer=tokenizer,
    data_collator=prepare_data_collator(tokenizer),
)
ift_trainer.train()

# Stage 3: Instruction Dataset Generation
instruction_data = generate_instruction_dataset(curated_data, model, tokenizer)

# Stage 4: Apply Adapters
model = apply_adapters(model, adapter_name="bio_adapter", save_path=ADAPTER_SAVE_DIR)

# Stage 5: SFT
sft_args = TrainingArguments(
    output_dir="./results_sft",
    per_device_train_batch_size=4,
    num_train_epochs=1,
    learning_rate=5e-5,
    fp16=True,
    save_strategy="no",
)

sft_trainer = Trainer(
    model=model,
    args=sft_args,
    train_dataset=instruction_data,
    tokenizer=tokenizer,
    data_collator=prepare_data_collator(tokenizer),
)
sft_trainer.train()

# Save final model
model.save_pretrained("spade_biogpt_clinical")
tokenizer.save_pretrained("spade_biogpt_clinical")
