import json
import torch
from torch.utils.data import Dataset
from transformers import DataCollatorForLanguageModeling
from peft import get_peft_model, LoraConfig, TaskType
from sentence_transformers.util import cos_sim

class CuratedTextDataset(Dataset):
    def __init__(self, texts, tokenizer, max_length=512):
        self.texts = texts
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        inputs = self.tokenizer(text, truncation=True, padding='max_length', max_length=self.max_length, return_tensors="pt")
        return {k: v.squeeze(0) for k, v in inputs.items()}

def curate_dataset(path, sentence_model, tokenizer, threshold=0.8):
    with open(path) as f:
        documents = json.load(f)
    seed = "clinical, medical treatment, diagnosis, pathology"
    seed_vec = sentence_model.encode(seed, convert_to_tensor=True)
    filtered = []
    for doc in documents:
        doc_vec = sentence_model.encode(doc, convert_to_tensor=True)
        score = cos_sim(seed_vec, doc_vec).item()
        if score >= threshold:
            filtered.append(doc)
    return CuratedTextDataset(filtered, tokenizer)

def generate_instruction_dataset(dataset, model, tokenizer):
    instruction_data = []
    for item in dataset.texts:
        prompt = f"Summarize the following:\n{item}"
        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
        output = model.generate(**inputs, max_length=128)
        result = tokenizer.decode(output[0], skip_special_tokens=True)
        instruction_data.append(f"### Instruction: {prompt}\n### Response: {result}")
    return CuratedTextDataset(instruction_data, tokenizer)

def apply_adapters(model, adapter_name, save_path):
    peft_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        inference_mode=False,
        r=8,
        lora_alpha=16,
        lora_dropout=0.1
    )
    peft_model = get_peft_model(model, peft_config)
    peft_model.save_pretrained(save_path)
    return peft_model

def prepare_data_collator(tokenizer):
    return DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)
